import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, ShieldCheck, Flame, Star, Sparkles, Plus, Trash2, CreditCard, Lock, Settings, Heart, Clock, ChefHat } from 'lucide-react';

export const Profil: React.FC = () => {
  const { user, progress, script, setScript, t, addChild, removeChild, setShowPaymentModal, setActiveTab, badges, recipes, favoriteRecipeIds, toggleFavoriteRecipe } = useApp();

  const [newChildName, setNewChildName] = useState('');
  const [newChildAge, setNewChildAge] = useState<number>(5);
  const [showAddChildModal, setShowAddChildModal] = useState(false);

  const favoriteRecipes = recipes.filter(r => favoriteRecipeIds.includes(r.id));

  const handleAddChildSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChildName.trim()) return;
    addChild(newChildName.trim(), Number(newChildAge));
    setNewChildName('');
    setNewChildAge(5);
    setShowAddChildModal(false);
  };

  return (
    <div className="space-y-6 pb-28 pt-2">
      
      {/* Profile Header Card */}
      <div className="bg-white p-5 rounded-3xl border border-[#EFE8DC] shadow-xs relative overflow-hidden">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF6B4A] to-[#FF8F73] flex items-center justify-center text-3xl shadow-md text-white font-black">
            👩‍👧
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-[#2D2A26]">
                {t(user.ism)}
              </h2>
              {user.is_premium && (
                <ShieldCheck className="w-5 h-5 text-amber-500 fill-amber-100" />
              )}
            </div>
            <p className="text-xs text-[#7C746B] font-medium">
              @{user.username}
            </p>
            <span className="inline-block mt-1 bg-[#F5F0E6] text-[#6B6359] text-[10px] font-bold px-2 py-0.5 rounded-full">
              ID: {user.telegram_id}
            </span>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-[#F5F0E6]">
          <div className="flex items-center gap-2.5 bg-[#FFF0EC] p-3 rounded-2xl border border-[#FFD5C8]">
            <Flame className="w-5 h-5 text-orange-500 fill-orange-500" />
            <div>
              <p className="text-xs text-[#7C746B] font-medium">{t("Streak")}</p>
              <p className="text-sm font-black text-[#2D2A26]">{progress.joriy_streak} {t("kun")}</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 bg-[#FFFBEB] p-3 rounded-2xl border border-[#FDE68A]">
            <Star className="w-5 h-5 text-amber-500 fill-amber-400" />
            <div>
              <p className="text-xs text-[#7C746B] font-medium">{t("Ballar")}</p>
              <p className="text-sm font-black text-[#2D2A26]">{progress.jami_ball} {t("ball")}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Subscription Card */}
      <div className="bg-gradient-to-r from-[#2D2A26] to-[#433E38] p-5 rounded-3xl text-white shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-300 bg-white/10 px-2.5 py-0.5 rounded-full">
              {user.is_premium ? t("Premium faol") : t("Sinov davri")}
            </span>
            <h3 className="text-lg font-bold mt-1">
              {user.is_premium ? t("Odobli.ai Premium A'zolik") : t("7 kunlik trial aktiv")}
            </h3>
            <p className="text-xs text-[#D1C9BD] mt-0.5">
              {user.is_premium
                ? t("Barcha kontent va imkoniyatlar ochiq.")
                : t("Sinov tugashiga 2 kun qoldi. Reklamasiz va to'liq kontent.")}
            </p>
          </div>
          <CreditCard className="w-8 h-8 text-amber-300 flex-shrink-0" />
        </div>

        <button
          onClick={() => setShowPaymentModal(true)}
          className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-amber-950 font-black text-xs rounded-2xl shadow-sm transition-all active:scale-98 flex items-center justify-center gap-1.5 min-h-[44px]"
        >
          <Sparkles className="w-4 h-4 fill-amber-950" />
          {user.is_premium ? t("Premium holatini ko'rish") : t("Premium sotib olish (25,000 so'm/oy)")}
        </button>
      </div>

      {/* Saved / Favorite Recipes Section */}
      <div className="bg-white p-4 rounded-3xl border border-[#EFE8DC] space-y-3 shadow-2xs">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-[#2D2A26] text-sm flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
            <span>{t("Sevimli Retseptlar (Saqlanganlar)")}</span>
          </h3>
          <span className="text-xs text-[#8C8479] font-bold">
            {favoriteRecipes.length} {t("ta saqlangan")}
          </span>
        </div>

        {favoriteRecipes.length === 0 ? (
          <div className="bg-[#FAF6EF] p-4 rounded-2xl border border-dashed border-[#E5DEC3] text-center space-y-1.5">
            <p className="text-xs font-bold text-[#6B6359]">
              {t("Hozircha sevimli retseptlar saqlanmagan")}
            </p>
            <p className="text-[11px] text-[#8C8479]">
              {t("Pazanda AI bo'limida retseptlar ustidagi yurakcha tugmasini bosib saqlashingiz mumkin.")}
            </p>
            <button
              onClick={() => setActiveTab('pazanda')}
              className="mt-2 text-xs font-black text-[#FF6B4A] hover:underline inline-flex items-center gap-1"
            >
              <ChefHat className="w-3.5 h-3.5" />
              <span>{t("Pazanda AI ga o'tish")} →</span>
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {favoriteRecipes.map(recipe => (
              <div
                key={recipe.id}
                className="bg-[#FAF6EF] p-2.5 rounded-2xl border border-[#EFE8DC] flex items-center justify-between gap-3 hover:border-[#FF6B4A] transition-all"
              >
                <div
                  onClick={() => setActiveTab('pazanda')}
                  className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                >
                  <img
                    src={recipe.rasm_url}
                    alt={recipe.nomi}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 object-cover rounded-xl shadow-2xs flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <h4 className="font-extrabold text-[#2D2A26] text-xs truncate">
                      {t(recipe.nomi)}
                    </h4>
                    <p className="text-[10px] text-[#7C746B] flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3 text-[#FF6B4A]" />
                      <span>{recipe.tayyorlash_vaqti_daq} {t("daq")}</span>
                      <span>•</span>
                      <span className="capitalize">{t(recipe.qiyinlik)}</span>
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => toggleFavoriteRecipe(recipe.id)}
                  className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors flex-shrink-0"
                  title={t("Olib tashlash")}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Badges & Achievements Grid */}
      <div className="bg-white p-4 rounded-3xl border border-[#EFE8DC] space-y-3 shadow-2xs">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-[#2D2A26] text-sm flex items-center gap-1.5">
            <span>{t("Unvonlar va Nishonlar")}</span>
            <span className="text-amber-500 font-extrabold text-xs">🏆</span>
          </h3>
          <span className="text-xs text-[#8C8479] font-bold">
            {badges.filter(b => b.ochilgan).length} / {badges.length} {t("ochilgan")}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {badges.map(badge => (
            <div
              key={badge.id}
              className={`p-3 rounded-2xl border transition-all ${
                badge.ochilgan
                  ? 'bg-[#FFFBF5] border-amber-200 text-[#2D2A26]'
                  : 'bg-gray-50 border-gray-200 text-gray-400 opacity-60'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-2xl">{badge.icon}</span>
                <div className="min-w-0">
                  <p className="font-extrabold text-xs truncate">{badge.nomi}</p>
                  <p className="text-[10px] text-[#8C8479] truncate">{badge.talab}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Language / Script Selector */}
      <div className="bg-white p-4 rounded-3xl border border-[#EFE8DC] space-y-3 shadow-2xs">
        <h3 className="font-extrabold text-[#2D2A26] text-sm flex items-center justify-between">
          <span>{t("Til va alifbo skripti")}</span>
          <span className="text-xs text-[#8C8479] font-normal">{t("Real vaqtda translate")}</span>
        </h3>

        <div className="grid grid-cols-2 gap-2 bg-[#F7F2EA] p-1 rounded-2xl border border-[#E8E1D5]">
          <button
            onClick={() => setScript('lotin')}
            className={`py-2.5 rounded-xl text-xs font-black transition-all ${
              script === 'lotin'
                ? 'bg-white text-[#2D2A26] shadow-xs'
                : 'text-[#7C746B] hover:text-[#2D2A26]'
            }`}
          >
            Lotin alifbosi
          </button>
          <button
            onClick={() => setScript('kirill')}
            className={`py-2.5 rounded-xl text-xs font-black transition-all ${
              script === 'kirill'
                ? 'bg-white text-[#2D2A26] shadow-xs'
                : 'text-[#7C746B] hover:text-[#2D2A26]'
            }`}
          >
            Кирилл алифбоси
          </button>
        </div>
      </div>

      {/* Children Manager */}
      <div className="bg-white p-4 rounded-3xl border border-[#EFE8DC] space-y-3 shadow-2xs">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-[#2D2A26] text-sm">
              {t("Bolalarim ma'lumoti")}
            </h3>
            <p className="text-xs text-[#8C8479]">
              {t("Faqat ism va yosh (minimal saqlash)")}
            </p>
          </div>
          <button
            onClick={() => setShowAddChildModal(true)}
            className="p-2 bg-[#FFF0EC] text-[#FF6B4A] hover:bg-[#FFE0D6] rounded-full transition-colors flex items-center gap-1 text-xs font-bold"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          {user.bolalar.map(child => (
            <div
              key={child.id}
              className="flex items-center justify-between bg-[#F9F6F0] p-3 rounded-2xl border border-[#EFE8DC]"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-xs">
                  👶
                </div>
                <div>
                  <p className="font-bold text-[#2D2A26] text-xs">{child.ism}</p>
                  <p className="text-[11px] text-[#7C746B]">{child.yosh} {t("yosh")}</p>
                </div>
              </div>
              <button
                onClick={() => removeChild(child.id)}
                className="text-rose-500 hover:bg-rose-50 p-1.5 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Admin Panel Toggle Mode Button */}
      <div className="pt-2">
        <button
          onClick={() => setActiveTab('admin')}
          className="w-full py-3 bg-[#F4EFE6] hover:bg-[#EAE4D9] text-[#524B43] text-xs font-extrabold rounded-2xl border border-[#E0D8C8] transition-colors flex items-center justify-center gap-2"
        >
          <Settings className="w-4 h-4 text-[#8C8479]" />
          {t("Admin Panel / Supabase Studio Rejimi")}
        </button>
      </div>

      {/* Modal for adding child */}
      {showAddChildModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-5 space-y-4 border border-[#EFE8DC] shadow-2xl">
            <h3 className="font-extrabold text-[#2D2A26] text-base">
              {t("Farzand qo'shish")}
            </h3>
            <form onSubmit={handleAddChildSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-[#6B6359] block mb-1">
                  {t("Ismi")}
                </label>
                <input
                  type="text"
                  required
                  placeholder="Masalan: Azizbek"
                  value={newChildName}
                  onChange={e => setNewChildName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#EFE8DC] text-xs text-[#2D2A26] focus:outline-none focus:border-[#FF6B4A]"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#6B6359] block mb-1">
                  {t("Yoshi")} (3-12)
                </label>
                <input
                  type="number"
                  min={3}
                  max={12}
                  value={newChildAge}
                  onChange={e => setNewChildAge(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#EFE8DC] text-xs text-[#2D2A26] focus:outline-none focus:border-[#FF6B4A]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddChildModal(false)}
                  className="flex-1 py-2.5 bg-[#F5F0E6] text-[#6B6359] text-xs font-bold rounded-xl"
                >
                  {t("Bekor qilish")}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#FF6B4A] text-white text-xs font-bold rounded-xl shadow-xs"
                >
                  {t("Saqlash")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
