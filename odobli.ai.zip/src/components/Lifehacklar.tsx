import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { Lifehack, LifehackCategory } from '../types';
import { Lightbulb, Sparkles, ChevronDown, ChevronUp, CheckCircle2 } from 'lucide-react';

export const Lifehacklar: React.FC = () => {
  const { lifehacks, t } = useApp();
  const [selectedCat, setSelectedCat] = useState<LifehackCategory | 'barchasi'>('barchasi');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories: { id: LifehackCategory | 'barchasi'; label: string }[] = [
    { id: 'barchasi', label: 'Barchasi' },
    { id: 'karving', label: 'Karving' },
    { id: 'oyinchoq_yasash', label: "O'yinchoq yasash" },
    { id: 'uy_ishlari', label: 'Uy ishlari' },
    { id: 'boshqa', label: 'Boshqa' },
  ];

  const filteredHacks = lifehacks.filter(lh => {
    if (lh.holat !== 'nashr') return false;
    if (selectedCat === 'barchasi') return true;
    return lh.kategoriya === selectedCat;
  });

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  return (
    <div className="space-y-4 pb-28 pt-1">
      
      {/* Header Banner */}
      <div className="card-3d p-3.5 rounded-2xl bg-gradient-to-r from-[#ECFDF5] to-[#D1FAE5] flex items-center justify-between border-[#A7F3D0]">
        <div>
          <div className="inline-flex items-center gap-1 bg-[#059669] text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full mb-1 border-b border-[#047857]">
            <Sparkles className="w-3 h-3 text-emerald-200" />
            {t("Foydali maslahatlar")}
          </div>
          <h2 className="text-lg font-extrabold text-[#2D2A26] tracking-tight">
            {t("Lifehacklar")}
          </h2>
          <p className="text-[11px] text-[#2D5A4C] mt-0.5 max-w-[220px]">
            {t("Oshxona, hunarmandchilik va ro'zg'or uchun tezkor yechimlar")}
          </p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-white border border-[#059669]/20 flex items-center justify-center text-2xl shadow-2xs">
          💡
        </div>
      </div>

      {/* Category Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 px-0.5">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCat(cat.id)}
            className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
              selectedCat === cat.id
                ? 'bg-[#059669] text-white shadow-2xs border-b-2 border-[#047857]'
                : 'bg-white text-[#6B6359] border border-[#EFE8DC] hover:bg-[#ECFDF5]'
            }`}
          >
            {t(cat.label)}
          </button>
        ))}
      </div>

      {/* Lifehack Cards */}
      <div className="space-y-2.5">
        {filteredHacks.map(lh => {
          const isExpanded = expandedId === lh.id;
          return (
            <motion.div
              key={lh.id}
              whileHover={{ y: -1.5 }}
              className="card-3d p-3 rounded-xl hover:border-[#059669] transition-all"
            >
              <div className="flex gap-3 items-start">
                <img
                  src={lh.rasm_url}
                  alt={lh.sarlavha}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 object-cover rounded-xl flex-shrink-0 shadow-2xs"
                />
                <div className="flex-1 min-w-0">
                  <span className="text-[9px] font-extrabold text-[#059669] bg-emerald-50 px-2 py-0.2 rounded-md border border-emerald-200 uppercase">
                    {t(lh.kategoriya)}
                  </span>
                  <h3 className="font-bold text-[#2D2A26] text-xs mt-1">
                    {t(lh.sarlavha)}
                  </h3>
                  <p className="text-[10.5px] text-[#6B6359] mt-0.5 line-clamp-2">
                    {t(lh.tavsif_matni)}
                  </p>
                </div>
              </div>

              {/* Expand button */}
              <button
                onClick={() => toggleExpand(lh.id)}
                className="w-full mt-2 pt-2 border-t border-[#F5F0E6] flex items-center justify-between text-xs font-bold text-[#059669] hover:underline"
              >
                <span>{isExpanded ? t("Bosqichlarni yashirish") : t("Batafsil bosqichlarni ko'rish")}</span>
                {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {/* Step-by-step content */}
              {isExpanded && (
                <div className="mt-3 pt-3 border-t border-dashed border-[#E5DEC3] space-y-2 animate-fadeIn">
                  <h4 className="font-extrabold text-xs text-[#2D2A26] uppercase tracking-wider mb-2">
                    {t("Ketma-ketlik bosqichlari")}:
                  </h4>
                  {lh.bosqichlar?.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-[#4A443C] bg-[#F7F5F0] p-2.5 rounded-xl border border-[#ECE5D8]">
                      <CheckCircle2 className="w-4 h-4 text-[#059669] flex-shrink-0 mt-0.5" />
                      <span>{t(step)}</span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

    </div>
  );
};
