import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { ActiveTab } from '../types';
import { Home, ChefHat, Sparkles, Lightbulb, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, t } = useApp();

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Bosh sahifa', icon: <Home className="w-4 h-4" /> },
    { id: 'pazanda', label: 'Pazanda AI', icon: <ChefHat className="w-4 h-4" /> },
    { id: 'bolajon', label: 'Bolajon', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'lifehacklar', label: 'Lifehacklar', icon: <Lightbulb className="w-4 h-4" /> },
    { id: 'profil', label: 'Profil', icon: <User className="w-4 h-4" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#FFFDF9]/95 backdrop-blur-lg border-t-2 border-[#EAE2D5] py-1.5 px-2 transition-all shadow-md">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.92 }}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all duration-150 min-w-[54px] min-h-[42px] relative ${
                isActive
                  ? 'text-[#FF6B4A] font-extrabold bg-[#FFF0EC] border border-[#FFD5C8]'
                  : 'text-[#8A8278] hover:text-[#4A443C] font-semibold'
              }`}
            >
              <div className={`transition-transform ${isActive ? 'scale-110 text-[#FF6B4A]' : ''}`}>
                {item.icon}
              </div>
              <span className="text-[10px] mt-0.5 leading-none tracking-tight whitespace-nowrap">
                {t(item.label)}
              </span>
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
};
