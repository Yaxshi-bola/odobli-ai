import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Flame, Star, ShieldCheck, Sparkles, Search, X, ChevronRight, ChefHat, BookOpen, Lightbulb } from 'lucide-react';

export const Header: React.FC = () => {
  const { user, progress, script, setScript, t, setActiveTab, recipes, tales, lifehacks } = useApp();
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');

  // Filter global results
  const filteredRecipes = recipes.filter(r => 
    globalSearch.trim() && (
      r.nomi.toLowerCase().includes(globalSearch.toLowerCase()) ||
      r.tarif_matni.toLowerCase().includes(globalSearch.toLowerCase())
    )
  );

  const filteredTales = tales.filter(t => 
    globalSearch.trim() && t.sarlavha.toLowerCase().includes(globalSearch.toLowerCase())
  );

  const filteredLifehacks = lifehacks.filter(l => 
    globalSearch.trim() && l.sarlavha.toLowerCase().includes(globalSearch.toLowerCase())
  );

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#FFFDF9]/95 backdrop-blur-md border-b-2 border-[#EAE2D5] px-3.5 py-2.5 transition-all shadow-xs">
        <div className="max-w-md mx-auto flex items-center justify-between">
          
          {/* Brand & Telegram User Info */}
          <div className="flex items-center gap-2">
            <div 
              onClick={() => setActiveTab('home')}
              className="w-9 h-9 rounded-xl bg-[#FF6B4A] border border-[#E05334] border-b-[3px] border-b-[#C83C1F] flex items-center justify-center text-white font-black text-lg shadow-2xs cursor-pointer active:translate-y-[2px] transition-all"
            >
              O
            </div>
            <div>
              <div className="flex items-center gap-1">
                <h1 className="font-extrabold text-[#2D2A26] text-base tracking-tight leading-none">
                  Odobli.ai
                </h1>
                {user.is_premium ? (
                  <span className="bg-amber-100 text-amber-800 text-[9px] font-extrabold px-1.5 py-0.2 rounded-md border border-amber-200">
                    PRO
                  </span>
                ) : (
                  <span className="bg-orange-100 text-orange-800 text-[9px] font-extrabold px-1.5 py-0.2 rounded-md border border-orange-200">
                    TRIAL
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#7C746B] line-clamp-1 font-medium mt-0.5">
                {t(user.ism)}
              </p>
            </div>
          </div>

          {/* Search & Script Switcher */}
          <div className="flex items-center gap-1.5">
            
            {/* Global Search Button */}
            <button
              onClick={() => setShowSearchModal(true)}
              className="p-1.5 text-[#635B52] hover:bg-[#F2ECE1] rounded-xl border border-[#E2D9CC] border-b-2 border-b-[#D0C5B5] active:translate-y-[1px] transition-all flex items-center justify-center"
              title="Qidirish"
            >
              <Search className="w-3.5 h-3.5" />
            </button>

            {/* Script Converter Toggle Button */}
            <button
              onClick={() => setScript(script === 'lotin' ? 'kirill' : 'lotin')}
              className="px-2.5 py-1 text-[11px] font-black transition-all bg-[#2D2A26] text-white hover:bg-[#3D3833] border border-[#1A1816] border-b-2 border-b-[#0D0C0B] active:translate-y-[1px] flex items-center gap-1 rounded-xl shadow-2xs shrink-0"
              title="Lotin ↔ Kirill yozuvini almashtirish"
            >
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>
                {script === 'lotin' ? 'Lotin' : 'Кирилл'}
              </span>
            </button>

          </div>

        </div>
      </header>

      {/* Global Search Overlay Modal */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 pt-12 animate-in fade-in duration-150">
          <div className="bg-[#FFFDF9] w-full max-w-md max-h-[85vh] rounded-3xl p-4.5 border border-[#EFE8DC] shadow-2xl flex flex-col space-y-3">
            
            <div className="flex items-center justify-between border-b border-[#EFE8DC] pb-2.5">
              <span className="text-xs font-black text-[#2D2A26] uppercase tracking-wider flex items-center gap-1.5">
                <Search className="w-4 h-4 text-[#FF6B4A]" />
                {t("Ummumiy Qidiruv")}
              </span>
              <button
                onClick={() => {
                  setShowSearchModal(false);
                  setGlobalSearch('');
                }}
                className="p-1 rounded-full hover:bg-gray-100 text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                autoFocus
                value={globalSearch}
                onChange={e => setGlobalSearch(e.target.value)}
                placeholder={t("Retsept, ertak yoki lifehack nomini yozing...")}
                className="w-full pl-9 pr-4 py-2.5 rounded-2xl bg-white border border-[#EFE8DC] text-xs focus:outline-none focus:border-[#FF6B4A]"
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 pt-1">
              {!globalSearch.trim() ? (
                <p className="text-center text-xs text-[#8C8479] py-8">
                  {t("Ilovadagi barcha retseptlar, ertaklar va lifehacklarni tezda toping.")}
                </p>
              ) : (
                <>
                  {/* Recipes Section */}
                  {filteredRecipes.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-black text-[#FF6B4A] flex items-center gap-1">
                        <ChefHat className="w-3.5 h-3.5" />
                        {t("Retseptlar")} ({filteredRecipes.length})
                      </p>
                      {filteredRecipes.map(r => (
                        <div
                          key={r.id}
                          onClick={() => {
                            setShowSearchModal(false);
                            setActiveTab('pazanda');
                          }}
                          className="p-2.5 rounded-xl bg-white border border-[#EFE8DC] hover:border-[#FF6B4A] cursor-pointer flex items-center justify-between text-xs"
                        >
                          <span className="font-bold text-[#2D2A26]">{t(r.nomi)}</span>
                          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Tales Section */}
                  {filteredTales.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-black text-[#7C3AED] flex items-center gap-1">
                        <BookOpen className="w-3.5 h-3.5" />
                        {t("Ertaklar")} ({filteredTales.length})
                      </p>
                      {filteredTales.map(tale => (
                        <div
                          key={tale.id}
                          onClick={() => {
                            setShowSearchModal(false);
                            setActiveTab('bolajon');
                          }}
                          className="p-2.5 rounded-xl bg-white border border-[#EFE8DC] hover:border-[#7C3AED] cursor-pointer flex items-center justify-between text-xs"
                        >
                          <span className="font-bold text-[#2D2A26]">{t(tale.sarlavha)}</span>
                          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Lifehacks Section */}
                  {filteredLifehacks.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-black text-[#059669] flex items-center gap-1">
                        <Lightbulb className="w-3.5 h-3.5" />
                        {t("Lifehacklar")} ({filteredLifehacks.length})
                      </p>
                      {filteredLifehacks.map(lh => (
                        <div
                          key={lh.id}
                          onClick={() => {
                            setShowSearchModal(false);
                            setActiveTab('lifehacklar');
                          }}
                          className="p-2.5 rounded-xl bg-white border border-[#EFE8DC] hover:border-[#059669] cursor-pointer flex items-center justify-between text-xs"
                        >
                          <span className="font-bold text-[#2D2A26]">{t(lh.sarlavha)}</span>
                          <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                      ))}
                    </div>
                  )}

                  {filteredRecipes.length === 0 && filteredTales.length === 0 && filteredLifehacks.length === 0 && (
                    <p className="text-center text-xs text-gray-500 py-6">
                      "{globalSearch}" {t("bo'yicha hech narsa topilmadi.")}
                    </p>
                  )}
                </>
              )}
            </div>

          </div>
        </div>
      )}
    </>
  );
};
