import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  Flame,
  Star,
  Utensils,
  BookOpen,
  Lightbulb,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Clock,
  Award,
  Crown,
  Heart,
  ArrowRight,
  Check
} from 'lucide-react';

export const BoshSahifa: React.FC = () => {
  const {
    progress,
    setActiveTab,
    t,
    recipes,
    tales,
    riddles,
    lifehacks,
    routineTasks,
    toggleRoutineTask,
    user
  } = useApp();

  // Carousel Banner State
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 0,
      title: "Pazanda AI — Mazali Retseptlar",
      subtitle: "Uydagi bor masalliqlardan milliy taomlar toping va porsiya bo'yicha hisoblang.",
      badge: "Aql-idrokli Pazanda",
      tab: 'pazanda',
      btnText: "Pazanda AI ga o'tish",
      bgClass: "from-[#FF6B4A] via-[#E8593A] to-[#C94326]",
      icon: "🍲"
    },
    {
      id: 1,
      title: "Sehrli Bolajon & Ertaklar",
      subtitle: "Sehrli ertaklar, audio hikoyalar va bilimni oshiruvchi qiziqarli o'yinlar!",
      badge: "Zukko Bolajon",
      tab: 'bolajon',
      btnText: "Bolajon bo'limiga o'tish",
      bgClass: "from-[#7C3AED] via-[#6D28D9] to-[#5B21B6]",
      icon: "🧸"
    },
    {
      id: 2,
      title: "Oila Kun Tartibi & Mukofotlar",
      subtitle: "Farzandlar bilan kunlik vazifalarni bajarib, yulduzcha ⭐ va ball to'plang.",
      badge: "Intizom va Tartib",
      tab: 'bolajon',
      btnText: "Vazifalarni ko'rish",
      bgClass: "from-[#059669] via-[#047857] to-[#065F46]",
      icon: "🏆"
    },
    {
      id: 3,
      title: "Oshxona & Ro'zg'or Lifehacklari",
      subtitle: "Ro'zg'or, oshxona va pazandalik bo'yicha eng sara foydali maslahatlar.",
      badge: "Foydali Lifehack",
      tab: 'lifehack',
      btnText: "Lifehacklarni ko'rish",
      bgClass: "from-[#D97706] via-[#B45309] to-[#92400E]",
      icon: "💡"
    }
  ];

  // Auto slide every 4.5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [slides.length]);

  const featuredRecipe = recipes[0];
  const featuredTale = tales[0];
  const featuredRiddle = riddles[0];
  const featuredLifehack = lifehacks[0];

  const completedTasksCount = routineTasks.filter(task => task.bajarildi).length;

  return (
    <div className="space-y-4 pb-28 pt-1">
      
      {/* Top Banner Hero Greetings */}
      <motion.div 
        whileHover={{ y: -1.5 }}
        className="card-3d-orange p-3 rounded-xl relative overflow-hidden"
      >
        <div className="flex items-center justify-between relative z-10">
          <div>
            <div className="inline-flex items-center gap-1 bg-orange-100 text-orange-900 text-[10px] font-black px-2 py-0.5 rounded-md mb-0.5 border border-orange-200">
              <Sparkles className="w-3 h-3 text-orange-600" />
              {t("Kunlik yangiliklar tayyor!")}
            </div>
            <h2 className="text-sm font-black text-[#2D2A26] tracking-tight">
              {t("Xush kelibsiz, Ona Mehribon!")}
            </h2>
            <p className="text-[11px] text-[#6B6359] mt-0.5 max-w-[240px]">
              {t("Bugun farzandlaringiz bilan birgalikda foydali faoliyatlarni bajaring.")}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-orange-100 border border-orange-200 flex items-center justify-center text-xl shadow-inner">
            👩‍👧‍👦
          </div>
        </div>
      </motion.div>

      {/* ROTATING HERO CAROUSEL BANNER */}
      <div className="relative rounded-2xl overflow-hidden shadow-xs border border-black/10 border-b-[3px] border-b-black/20">
        <div className={`bg-gradient-to-r ${slides[currentSlide].bgClass} text-white p-4 transition-all duration-500 flex flex-col justify-between min-h-[140px]`}>
          
          <div className="flex items-start justify-between relative z-10">
            <div className="space-y-1 max-w-[250px]">
              <span className="bg-white/20 text-white text-[9px] font-black px-2 py-0.5 rounded-md inline-flex items-center gap-1 backdrop-blur-xs border border-white/20">
                <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                {t(slides[currentSlide].badge)}
              </span>
              <h3 className="text-base font-black tracking-tight leading-tight">
                {t(slides[currentSlide].title)}
              </h3>
              <p className="text-[11px] text-white/90 leading-snug line-clamp-2">
                {t(slides[currentSlide].subtitle)}
              </p>
            </div>
            <span className="text-4xl drop-shadow-md select-none">{slides[currentSlide].icon}</span>
          </div>

          <div className="flex items-center justify-between pt-2.5 relative z-10">
            <button
              onClick={() => setActiveTab(slides[currentSlide].tab as 'pazanda' | 'bolajon' | 'lifehack')}
              className="px-3.5 py-1.5 bg-white text-[#2D2A26] hover:bg-stone-100 rounded-xl text-xs font-black flex items-center gap-1 shadow-2xs active:translate-y-[1px] transition-transform"
            >
              <span>{t(slides[currentSlide].btnText)}</span>
              <ArrowRight className="w-3 h-3 text-[#FF6B4A]" />
            </button>

            {/* Carousel Navigation Dots */}
            <div className="flex items-center gap-1">
              {slides.map((s, idx) => (
                <button
                  key={s.id}
                  onClick={() => setCurrentSlide(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    currentSlide === idx ? 'w-5 bg-white' : 'w-1.5 bg-white/40'
                  }`}
                />
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Section Title: Bugungi Faoliyat */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-0.5">
          <h3 className="font-extrabold text-[#2D2A26] text-xs tracking-tight flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#FF6B4A]" />
            {t("Bugungi faoliyatlar")}
          </h3>
          <span className="text-[11px] text-[#8C8479] font-medium">
            {new Date().toLocaleDateString('uz-UZ', { month: 'short', day: 'numeric' })}
          </span>
        </div>

        {/* 2x2 Activity Cards Grid */}
        <div className="grid grid-cols-2 gap-2">
          
          {/* Card 1: Bugungi taom g'oyasi */}
          <motion.div 
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            className="bg-[#FFF8F5] p-2.5 rounded-xl border border-[#FFD8CC] border-b-2 border-b-[#FFAF9B] flex flex-col justify-between shadow-2xs relative overflow-hidden"
          >
            <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-white flex items-center justify-center text-[10px] shadow-2xs">
              🍲
            </div>
            <div>
              <span className="text-[8.5px] font-black uppercase text-[#D94826] bg-white px-1.5 py-0.2 rounded-md border border-[#FFC8B8]">
                {t("Taom g'oyasi")}
              </span>
              <h4 className="font-bold text-[#2D2A26] text-[11px] mt-1 line-clamp-1">
                {t(featuredRecipe?.nomi || "Sabzavotli dimlama")}
              </h4>
              <p className="text-[8.5px] text-[#6E5D52] mt-0.5 line-clamp-1">
                {featuredRecipe?.tayyorlash_vaqti_daq} {t("daq")} • {t(featuredRecipe?.qiyinlik || 'oson')}
              </p>
            </div>

            <div className="mt-1.5">
              <img
                src={featuredRecipe?.rasm_url}
                alt={featuredRecipe?.nomi}
                referrerPolicy="no-referrer"
                className="w-full h-14 object-cover rounded-lg mb-1.5 shadow-2xs border border-[#FFC8B8]"
              />
              <button
                onClick={() => setActiveTab('pazanda')}
                className="btn-3d-primary w-full py-1 text-[10.5px] flex items-center justify-center gap-0.5"
              >
                {t("Ko'rish")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </motion.div>

          {/* Card 2: Bolajon Ertagi */}
          <motion.div 
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            className="bg-[#F8F5FF] p-2.5 rounded-xl border border-[#E0D5FF] border-b-2 border-b-[#C9B8FF] flex flex-col justify-between shadow-2xs relative overflow-hidden"
          >
            <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-white flex items-center justify-center text-[10px] shadow-2xs">
              🏰
            </div>
            <div>
              <span className="text-[8.5px] font-black uppercase text-[#6B46C1] bg-white px-1.5 py-0.2 rounded-md border border-[#D5C8FF]">
                {t("Ertak")}
              </span>
              <h4 className="font-bold text-[#2D2A26] text-[11px] mt-1 line-clamp-1">
                {t(featuredTale?.sarlavha || "Mehrli quyoncha")}
              </h4>
              <p className="text-[8.5px] text-[#584D70] mt-0.5 line-clamp-1">
                {featuredTale?.yosh_toifasi} {t("yosh")}
              </p>
            </div>

            <div className="mt-1.5">
              <img
                src={featuredTale?.muqova_rasm_url}
                alt={featuredTale?.sarlavha}
                referrerPolicy="no-referrer"
                className="w-full h-14 object-cover rounded-lg mb-1.5 shadow-2xs border border-[#D5C8FF]"
              />
              <button
                onClick={() => setActiveTab('bolajon')}
                className="w-full py-1 bg-[#7C3AED] hover:bg-[#6D28D9] text-white text-[10.5px] font-black border border-[#6328C6] border-b-2 border-b-[#4E1E9E] rounded-lg active:translate-y-[1px] transition-all flex items-center justify-center gap-0.5"
              >
                {t("Bolajon")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </motion.div>

          {/* Card 3: Topishmoq & Masala */}
          <motion.div 
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            className="bg-[#FFFDF0] p-2.5 rounded-xl border border-[#FDE68A] border-b-2 border-b-[#FCD34D] flex flex-col justify-between shadow-2xs relative overflow-hidden"
          >
            <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-white flex items-center justify-center text-[10px] shadow-2xs">
              🧩
            </div>
            <div>
              <span className="text-[8.5px] font-black uppercase text-[#B45309] bg-white px-1.5 py-0.2 rounded-md border border-[#FDE68A]">
                {t("Topishmoq")}
              </span>
              <h4 className="font-bold text-[#2D2A26] text-[11px] mt-1 line-clamp-2 leading-tight">
                "{t(featuredRiddle?.savol || "Ko'zi bor, boshi yo'q...")}"
              </h4>
            </div>

            <div className="mt-1.5">
              <div className="bg-white/90 p-1 rounded-lg border border-amber-200/80 mb-1.5 text-center">
                <p className="text-[8.5px] text-amber-900 font-extrabold">
                  +15 {t("ball to'plang")}
                </p>
              </div>
              <button
                onClick={() => setActiveTab('bolajon')}
                className="w-full py-1 bg-[#D97706] hover:bg-[#B45309] text-white text-[10.5px] font-black border border-[#B45309] border-b-2 border-b-[#92400E] rounded-lg active:translate-y-[1px] transition-all flex items-center justify-center gap-0.5"
              >
                {t("Yechish")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </motion.div>

          {/* Card 4: Ro'zg'or Lifehack */}
          <motion.div 
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.98 }}
            className="bg-[#F0FDF4] p-2.5 rounded-xl border border-[#A7F3D0] border-b-2 border-b-[#6EE7B7] flex flex-col justify-between shadow-2xs relative overflow-hidden"
          >
            <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-white flex items-center justify-center text-[10px] shadow-2xs">
              💡
            </div>
            <div>
              <span className="text-[8.5px] font-black uppercase text-[#047857] bg-white px-1.5 py-0.2 rounded-md border border-[#A7F3D0]">
                {t("Lifehack")}
              </span>
              <h4 className="font-bold text-[#2D2A26] text-[11px] mt-1 line-clamp-1">
                {t(featuredLifehack?.sarlavha || "Sabzavotlardan atirgul")}
              </h4>
              <p className="text-[8.5px] text-[#2D5A4C] mt-0.5 line-clamp-1">
                {t("Amaliy maslahat")}
              </p>
            </div>

            <div className="mt-1.5">
              <img
                src={featuredLifehack?.rasm_url}
                alt={featuredLifehack?.sarlavha}
                referrerPolicy="no-referrer"
                className="w-full h-14 object-cover rounded-lg mb-1.5 shadow-2xs border border-[#A7F3D0]"
              />
              <button
                onClick={() => setActiveTab('lifehacklar')}
                className="w-full py-1 bg-[#059669] hover:bg-[#047857] text-white text-[10.5px] font-black border border-[#047857] border-b-2 border-b-[#065F46] rounded-lg active:translate-y-[1px] transition-all flex items-center justify-center gap-0.5"
              >
                {t("O'tish")}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </motion.div>

        </div>
      </div>

    </div>
  );
};
