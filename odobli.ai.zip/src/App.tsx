import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { BoshSahifa } from './components/BoshSahifa';
import { PazandaAI } from './components/PazandaAI';
import { Bolajon } from './components/Bolajon';
import { Lifehacklar } from './components/Lifehacklar';
import { Profil } from './components/Profil';
import { AdminPanel } from './components/AdminPanel';
import { PaymentModal } from './components/PaymentModal';
import { RewardModal } from './components/RewardModal';

const AppContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="min-h-screen bg-[#FAF6EF] text-[#2D2A26] font-sans antialiased selection:bg-[#FF6B4A]/20">
      
      {/* Container wrapper constrained for mobile / desktop layout */}
      <div className="max-w-md mx-auto min-h-screen bg-[#FFFDF9] shadow-xl border-x border-[#EFE8DC] flex flex-col relative">
        
        {/* Sticky Header */}
        <Header />

        {/* Main View Area based on Active Tab */}
        <main className="flex-1 px-4 pt-3">
          {activeTab === 'home' && <BoshSahifa />}
          {activeTab === 'pazanda' && <PazandaAI />}
          {activeTab === 'bolajon' && <Bolajon />}
          {activeTab === 'lifehacklar' && <Lifehacklar />}
          {activeTab === 'profil' && <Profil />}
          {activeTab === 'admin' && <AdminPanel />}
        </main>

        {/* Fixed Mobile Bottom Bar */}
        <BottomNav />

        {/* Global Modals */}
        <PaymentModal />
        <RewardModal />

      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
