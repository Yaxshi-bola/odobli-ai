import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserProgress,
  ScriptType,
  ActiveTab,
  Recipe,
  Ingredient,
  Tale,
  Lifehack,
  Riddle,
  MathProblem,
  PaymentProof,
  Child,
  RoutineTask,
  Badge,
  ShoppingItem
} from '../types';
import {
  initialIngredients,
  initialRecipes,
  initialTales,
  initialLifehacks,
  initialRiddles,
  initialMathProblems
} from '../data/mockData';
import { translateText } from '../utils/transliterate';

interface RewardDetails {
  title: string;
  points: number;
  streak: number;
  message: string;
}

interface AppContextType {
  user: User;
  progress: UserProgress;
  script: ScriptType;
  setScript: (s: ScriptType) => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  t: (text: string) => string;

  // Data collections
  ingredients: Ingredient[];
  recipes: Recipe[];
  tales: Tale[];
  lifehacks: Lifehack[];
  riddles: Riddle[];
  mathProblems: MathProblem[];
  paymentProofs: PaymentProof[];
  routineTasks: RoutineTask[];
  badges: Badge[];
  shoppingList: ShoppingItem[];
  favoriteRecipeIds: string[];
  toggleFavoriteRecipe: (id: string) => void;

  // Actions
  toggleRoutineTask: (id: string) => void;
  addRecipe: (recipe: Recipe) => void;
  addTale: (tale: Tale) => void;
  addLifehack: (lh: Lifehack) => void;
  toggleRecipeStatus: (id: string) => void;

  // Shopping List Actions
  addToShoppingList: (nomi: string, miqdori?: string) => void;
  addMultipleToShoppingList: (items: { nomi: string; miqdori?: string }[]) => void;
  toggleShoppingItem: (id: string) => void;
  removeShoppingItem: (id: string) => void;
  clearShoppingList: () => void;

  // Payment Actions
  submitPaymentProof: (summa: number, screenshot: string) => void;
  verifyPaymentProof: (id: string, status: 'tasdiqlangan' | 'rad_etilgan') => void;

  // User & Child Actions
  addChild: (ism: string, yosh: number) => void;
  removeChild: (id: string) => void;

  // Gamification Actions
  completeActivity: (type: 'topishmoq' | 'masala' | 'kunlik', itemId: string, earnedPoints: number) => void;
  completedItemIds: string[];

  // Modals state
  rewardDetails: RewardDetails | null;
  setRewardDetails: (d: RewardDetails | null) => void;
  showPaymentModal: boolean;
  setShowPaymentModal: (v: boolean) => void;
  selectedAgeFilter: string;
  setSelectedAgeFilter: (age: string) => void;
}

const defaultUser: User = {
  id: 'usr_mother_1',
  telegram_id: 8492049,
  username: 'onamehribon',
  ism: 'Ona Mehribon',
  til_skripti: 'lotin',
  bolalar: [
    { id: 'c1', ism: 'Azizbek', yosh: 5 },
    { id: 'c2', ism: 'Madina', yosh: 8 }
  ],
  trial_ends_at: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
  is_premium: false,
  premium_until: null,
  created_at: new Date().toISOString()
};

const defaultProgress: UserProgress = {
  user_id: 'usr_mother_1',
  jami_ball: 125,
  joriy_streak: 7,
  eng_uzun_streak: 12,
  oxirgi_faollik_sanasi: new Date().toISOString().split('T')[0]
};

const defaultRoutineTasks: RoutineTask[] = [
  { id: 'task_1', sarlavha: "Ertalabki badan tarbiya mashqi", vaqt: "08:00", kategoriya: 'bola', ball: 10, bajarildi: false, icon: '🏃‍♂️' },
  { id: 'task_2', sarlavha: "Farzandga 15 daqiqa ertak o'qish", vaqt: "13:00", kategoriya: 'ona', ball: 15, bajarildi: false, icon: '📖' },
  { id: 'task_3', sarlavha: "Vitaminga boy tushlik pishirish", vaqt: "14:00", kategoriya: 'ona', ball: 15, bajarildi: false, icon: '🥗' },
  { id: 'task_4', sarlavha: "O'yinchoqlarni tartib bilan yig'ish", vaqt: "18:00", kategoriya: 'bola', ball: 10, bajarildi: false, icon: '🧸' },
  { id: 'task_5', sarlavha: "Mantiqiy topishmoq o'yini", vaqt: "19:30", kategoriya: 'bola', ball: 20, bajarildi: false, icon: '🧩' },
];

const defaultBadges: Badge[] = [
  { id: 'b_pazanda', nomi: 'Oltin Pazanda', tavsif: "Pazanda AI va retseptlardan 5 marta foydalandingiz", icon: '👩‍🍳', ochilgan: true, talab: "5 ta retsept" },
  { id: 'b_ertak', nomi: 'Ertakchi Ona', tavsif: "Farzandingizga 3 ta sehrli ertak o'qib berdingiz", icon: '📚', ochilgan: true, talab: "3 ta ertak" },
  { id: 'b_streak', nomi: 'Muntazam Ona', tavsif: "7 kun ketma-ket ilovadan unumli foydalandingiz", icon: '🔥', ochilgan: true, talab: "7 kunlik streak" },
  { id: 'b_zukko', nomi: 'Zukko Bolajon', tavsif: "Topishmoqlar va masalalardan 100 ball to'pladingiz", icon: '⭐', ochilgan: true, talab: "100 ball" },
  { id: 'b_premium', nomi: 'Mukammal Oila', tavsif: "Premium obuna va barcha maxsus imkoniyatlarni ochdingiz", icon: '👑', ochilgan: false, talab: "Premium status" }
];

const defaultShoppingList: ShoppingItem[] = [
  { id: 'shop_1', nomi: 'Sabzi (Sariq va Qizil)', miqdori: '2 kg', bajarildi: false },
  { id: 'shop_2', nomi: "Qo'y go'shti (Qovurg'a)", miqdori: '1 kg', bajarildi: false },
  { id: 'shop_3', nomi: 'Lazer Guruch', miqdori: '1 kg', bajarildi: true },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // LocalStorage initialization helper
  const loadStorage = <T,>(key: string, fallback: T): T => {
    try {
      const saved = localStorage.getItem(`odobli_${key}`);
      return saved ? JSON.parse(saved) : fallback;
    } catch {
      return fallback;
    }
  };

  const [user, setUser] = useState<User>(() => loadStorage('user', defaultUser));
  const [progress, setProgress] = useState<UserProgress>(() => loadStorage('progress', defaultProgress));
  const [script, setScriptState] = useState<ScriptType>(() => loadStorage('script', 'lotin'));
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [selectedAgeFilter, setSelectedAgeFilter] = useState<string>('Barchasi');

  // Datasets
  const [ingredients] = useState<Ingredient[]>(initialIngredients);
  const [recipes, setRecipes] = useState<Recipe[]>(() => {
    const saved = loadStorage<Recipe[]>('recipes', initialRecipes);
    return saved.length < initialRecipes.length ? initialRecipes : saved;
  });
  const [tales, setTales] = useState<Tale[]>(() => loadStorage('tales', initialTales));
  const [lifehacks, setLifehacks] = useState<Lifehack[]>(() => loadStorage('lifehacks', initialLifehacks));
  const [riddles] = useState<Riddle[]>(initialRiddles);
  const [mathProblems] = useState<MathProblem[]>(initialMathProblems);
  const [paymentProofs, setPaymentProofs] = useState<PaymentProof[]>(() => loadStorage('payments', []));
  const [completedItemIds, setCompletedItemIds] = useState<string[]>(() => loadStorage('completed_items', []));
  const [routineTasks, setRoutineTasks] = useState<RoutineTask[]>(() => loadStorage('routine_tasks', defaultRoutineTasks));
  const [badges] = useState<Badge[]>(() => loadStorage('badges', defaultBadges));
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>(() => loadStorage('shopping_list', defaultShoppingList));
  const [favoriteRecipeIds, setFavoriteRecipeIds] = useState<string[]>(() => loadStorage('favorite_recipes', ['rec_1', 'rec_3']));

  const toggleFavoriteRecipe = (id: string) => {
    setFavoriteRecipeIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Modals
  const [rewardDetails, setRewardDetails] = useState<RewardDetails | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('odobli_routine_tasks', JSON.stringify(routineTasks));
  }, [routineTasks]);

  useEffect(() => {
    localStorage.setItem('odobli_badges', JSON.stringify(badges));
  }, [badges]);

  useEffect(() => {
    localStorage.setItem('odobli_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('odobli_progress', JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    localStorage.setItem('odobli_script', JSON.stringify(script));
  }, [script]);

  useEffect(() => {
    localStorage.setItem('odobli_recipes', JSON.stringify(recipes));
  }, [recipes]);

  useEffect(() => {
    localStorage.setItem('odobli_tales', JSON.stringify(tales));
  }, [tales]);

  useEffect(() => {
    localStorage.setItem('odobli_lifehacks', JSON.stringify(lifehacks));
  }, [lifehacks]);

  useEffect(() => {
    localStorage.setItem('odobli_payments', JSON.stringify(paymentProofs));
  }, [paymentProofs]);

  useEffect(() => {
    localStorage.setItem('odobli_completed_items', JSON.stringify(completedItemIds));
  }, [completedItemIds]);

  useEffect(() => {
    localStorage.setItem('odobli_shopping_list', JSON.stringify(shoppingList));
  }, [shoppingList]);

  useEffect(() => {
    localStorage.setItem('odobli_favorite_recipes', JSON.stringify(favoriteRecipeIds));
  }, [favoriteRecipeIds]);

  const setScript = (s: ScriptType) => {
    setScriptState(s);
    setUser(prev => ({ ...prev, til_skripti: s }));
  };

  const t = (text: string) => {
    return translateText(text, script);
  };

  // Add Child
  const addChild = (ism: string, yosh: number) => {
    const newChild: Child = { id: `child_${Date.now()}`, ism, yosh };
    setUser(prev => ({
      ...prev,
      bolalar: [...prev.bolalar, newChild]
    }));
  };

  const removeChild = (id: string) => {
    setUser(prev => ({
      ...prev,
      bolalar: prev.bolalar.filter(c => c.id !== id)
    }));
  };

  // Shopping List Actions
  const addToShoppingList = (nomi: string, miqdori?: string) => {
    if (!nomi.trim()) return;
    const newItem: ShoppingItem = {
      id: `shop_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      nomi: nomi.trim(),
      miqdori: miqdori?.trim(),
      bajarildi: false
    };
    setShoppingList(prev => [newItem, ...prev]);
  };

  const addMultipleToShoppingList = (items: { nomi: string; miqdori?: string }[]) => {
    const newItems: ShoppingItem[] = items.map(item => ({
      id: `shop_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      nomi: item.nomi.trim(),
      miqdori: item.miqdori?.trim(),
      bajarildi: false
    }));
    setShoppingList(prev => [...newItems, ...prev]);
  };

  const toggleShoppingItem = (id: string) => {
    setShoppingList(prev =>
      prev.map(item => (item.id === id ? { ...item, bajarildi: !item.bajarildi } : item))
    );
  };

  const removeShoppingItem = (id: string) => {
    setShoppingList(prev => prev.filter(item => item.id !== id));
  };

  const clearShoppingList = () => {
    setShoppingList([]);
  };

  // Gamification Completion
  const completeActivity = (_type: string, itemId: string, earnedPoints: number) => {
    if (completedItemIds.includes(itemId)) {
      setRewardDetails({
        title: "Taqdirlandiz! 🎉",
        points: 0,
        streak: progress.joriy_streak,
        message: "Bu topshiriqni bugun bajargansiz!"
      });
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const lastActiveDate = progress.oxirgi_faollik_sanasi;
    let newStreak = progress.joriy_streak;

    if (lastActiveDate !== todayStr) {
      newStreak += 1;
    }

    const newPoints = progress.jami_ball + earnedPoints;
    const newProgress: UserProgress = {
      ...progress,
      jami_ball: newPoints,
      joriy_streak: newStreak,
      eng_uzun_streak: Math.max(newStreak, progress.eng_uzun_streak),
      oxirgi_faollik_sanasi: todayStr
    };

    setProgress(newProgress);
    setCompletedItemIds(prev => [...prev, itemId]);

    setRewardDetails({
      title: "Ajoyib! 🏆",
      points: earnedPoints,
      streak: newStreak,
      message: "Barakalla! Bilimingiz va faolligingiz oshib bormoqda."
    });
  };

  // Admin recipe
  const addRecipe = (recipe: Recipe) => {
    setRecipes(prev => [recipe, ...prev]);
  };

  const addTale = (tale: Tale) => {
    setTales(prev => [tale, ...prev]);
  };

  const addLifehack = (lh: Lifehack) => {
    setLifehacks(prev => [lh, ...prev]);
  };

  const toggleRecipeStatus = (id: string) => {
    setRecipes(prev =>
      prev.map(r => (r.id === id ? { ...r, holat: r.holat === 'nashr' ? 'qoralama' : 'nashr' } : r))
    );
  };

  // Payment flow
  const submitPaymentProof = (summa: number, screenshot: string) => {
    const proof: PaymentProof = {
      id: `pay_${Date.now()}`,
      user_id: user.id,
      summa,
      screenshot_file_id: `file_tg_${Date.now()}`,
      screenshot_preview_url: screenshot,
      holat: 'kutilmoqda',
      created_at: new Date().toISOString()
    };
    setPaymentProofs(prev => [proof, ...prev]);
  };

  const verifyPaymentProof = (id: string, status: 'tasdiqlangan' | 'rad_etilgan') => {
    setPaymentProofs(prev =>
      prev.map(p => {
        if (p.id === id) {
          return {
            ...p,
            holat: status,
            tasdiqlangan_at: new Date().toISOString()
          };
        }
        return p;
      })
    );

    if (status === 'tasdiqlangan') {
      setUser(prev => ({
        ...prev,
        is_premium: true,
        premium_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      }));
    }
  };

  const toggleRoutineTask = (taskId: string) => {
    let taskPoints = 0;
    let newlyCompleted = false;

    setRoutineTasks(prev =>
      prev.map(task => {
        if (task.id === taskId) {
          newlyCompleted = !task.bajarildi;
          taskPoints = task.ball;
          return { ...task, bajarildi: newlyCompleted };
        }
        return task;
      })
    );

    if (newlyCompleted) {
      completeActivity('kunlik', taskId, taskPoints);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        progress,
        script,
        setScript,
        activeTab,
        setActiveTab,
        t,
        ingredients,
        recipes,
        tales,
        lifehacks,
        riddles,
        mathProblems,
        paymentProofs,
        routineTasks,
        badges,
        shoppingList,
        favoriteRecipeIds,
        toggleFavoriteRecipe,
        toggleRoutineTask,
        addRecipe,
        addTale,
        addLifehack,
        toggleRecipeStatus,
        addToShoppingList,
        addMultipleToShoppingList,
        toggleShoppingItem,
        removeShoppingItem,
        clearShoppingList,
        submitPaymentProof,
        verifyPaymentProof,
        addChild,
        removeChild,
        completeActivity,
        completedItemIds,
        rewardDetails,
        setRewardDetails,
        showPaymentModal,
        setShowPaymentModal,
        selectedAgeFilter,
        setSelectedAgeFilter
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
